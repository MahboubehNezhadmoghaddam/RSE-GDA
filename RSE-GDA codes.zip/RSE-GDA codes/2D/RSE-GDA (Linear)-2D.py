# 2D
# Gradient descent method with calculationg one alpha for all points in each iteration.

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# Step 1: Generating initial points on Linear manifold
def generate_initial_points(num_points, dimensions):
    points = np.random.rand(num_points, dimensions)
    points /= np.sum(points, axis=1, keepdims=True)
    return points

# Step 2: Riesz s-Energy Function
def riesz_s_energy(PFA, s):
    n = len(PFA)
    diff = PFA[:, np.newaxis, :] - PFA[np.newaxis, :, :]
    norms = np.linalg.norm(diff, axis=2) + 1e-12  # Add small epsilon to prevent division by zero
    np.fill_diagonal(norms, np.inf)  # Avoid self-interaction
    return np.sum(1 / norms**s)

# Step 3: Gradient of Riesz s-Energy 
def gradient_riesz_s_energy(A, s):
    n = A.shape[0]
    grad = np.zeros_like(A)
    for i in range(n):
        diff = A[i] - A
        norms = np.linalg.norm(diff, axis=1) + 1e-12  # Add small epsilon
        norms[i] = np.inf  # Avoid self-interaction
        grad[i] = -s * np.sum(diff / norms[:, np.newaxis]**(s + 2), axis=0)
    return grad

# Step 4: Calculating the projection of Gradient 
def project_onto_tangent_space(gradient, a):
    dot_product = np.dot(gradient, a)
    tangent_projection = gradient - dot_product * a
    return tangent_projection

# Normalize the tangent projection
def normalize_to_simplex(x): 
    x = np.maximum(x, 0)
    x_sum = np.sum(x)
    if (x_sum > 0).any():
        return x / x_sum
    else:
        return x

def project_and_normalize(A, s):
    projections = []
    grad = gradient_riesz_s_energy(A, s)
    for i in range(len(grad)):
        # Project the gradient onto the tangent space
        projection = project_onto_tangent_space(grad[i], A[i])

        # Normalize the projection to lie on the simplex unit
        normalized_projection = normalize_to_simplex(projection)

        # Store the normalized projection
        projections.append(normalized_projection)
    return np.array(projections)

# Step 5: Function and Gradient
def func(A):
    return riesz_s_energy(A, s=s )
def grad_func(A):
    return gradient_riesz_s_energy(A, s=s )
def proj_grad_func(A):
    return project_and_normalize(A, s=s )

# Step 6: Gradient descent method
def steepest_descent(x0, func, grad_func, proj_grad_func, c1=1e-3, c2=0.9, eps=1e-6, max_iters=3000, verbose=False):
    x = np.array(x0)       # Make sure we are using a np array
    gradient_norms = []    # List for storing grad
    energy_values = []  

    for i in range(max_iters):
        energy_values.append(func(x))
        grad = proj_grad_func(x)
        grad_stop = grad_func(x)
        grad_stop_norm = np.linalg.norm(grad_stop)
        gradient_norms.append(grad_stop_norm)
        
        # Check the norm of the gradient
        if grad_stop_norm < eps:
            if verbose:
                print(f'Steepest descent converged at iteration {i}')
            return x, gradient_norms, energy_values

        pk = -grad

        alpha = strong_wolfe(func, proj_grad_func, x, pk, c1=c1, c2=c2, verbose=verbose)
        if alpha is None:
            break
        
        x += alpha * pk
        x = np.array([normalize_to_simplex(xi) for xi in x])
    
        if verbose:
            print(f'Iteration {i}, alpha: {alpha}, x: {x}')   
    if verbose:
        print('Steepest descent failed to converge')
    return x, gradient_norms, energy_values

# Step 7: Line Search Algorithm For Strong Wolfe Condition
def strong_wolfe(func, proj_grad_func, x, pk, c1=1e-3, c2=0.9, alpha=0.001, alpha_max=1.0, max_iters=300, verbose=False):

    # Compute the function and the gradient at alpha = 0
    fk = func(x)
    gk = proj_grad_func(x)

    proj_gk = np.dot(gk.flatten(), pk.flatten())

    # Store the old value of the objective
    fk_old = fk
    proj_gk_old = proj_gk
    alpha_old = 0.0

    for j in range(max_iters):
        x_new = x + alpha * pk
        
        # Evaluate the merit function and the gradient at the new point
        fk_new = func(x_new)
        gk_new = proj_grad_func(x_new)
        proj_gk_new = np.dot(gk_new.flatten(), pk.flatten())

        # Check if either the sufficient decrease condition is violated or the objective increased
        if fk_new > fk + c1 * alpha * proj_gk or (j > 1 and fk_new >= fk_old):
            if verbose:
                print('Sufficient decrease conditions violated: interval found')
            return zoom(func, proj_grad_func, fk_old, proj_gk_old, alpha_old, fk_new, proj_gk_new, alpha, x, fk, gk, pk, c1=c1, c2=c2, verbose=verbose)

        # Check if the strong Wolfe conditions are satisfied   
        if np.abs(proj_gk_new) <= c2 * np.abs(proj_gk):
            if verbose:
                print('Strong Wolfe alpha found directly')
            return alpha

        # If the line search is vioalted
        if proj_gk_new >= 0.0:
            if verbose:
                print('Slope condition violated; interval found')
            return zoom(func, proj_grad_func, fk_new, proj_gk_new, alpha, fk_old, proj_gk_old, alpha_old, x, fk, gk, pk, c1=c1, c2=c2, verbose=verbose)

        # Record the old values of alpha and fk 
        fk_old = fk_new
        proj_gk_old = proj_gk_new
        alpha_old = alpha

        # Pick a new value for alpha
        alpha = min(2.0 * alpha, alpha_max)

        if alpha >= alpha_max:
            if verbose:
                print('Line search failed here')
            return None

    if verbose:
        print('Line search unsuccessful')
    return alpha

def zoom(func, proj_grad_func, f_low, proj_low, alpha_low, f_high, proj_high, alpha_high,
         x, fk, gk, pk, c1=1e-3, c2=0.9, max_iters=100, verbose=False):
    
    '''
    Zoom function: Locate a value between alpha_low and alpha_high
    that satisfies the strong Wolfe conditions. Remember:
    alpha_low/alpha_high are step lengths yielding the
    lowest/higher values of the merit function. 

    alpha:   a step length satisfying the strong Wolfe conditions
    '''
    proj_gk = np.dot(gk.flatten(), pk.flatten())

    for j in range(max_iters):
        # Pick an alpha value using cubic interpolation for each point
        alpha_j = cubic_interp(alpha_low, f_low, proj_low, alpha_high, f_high, proj_high)
        
        # The validation of alpha_j
        if alpha_j is None or not np.isfinite(alpha_j):
            alpha_j = (alpha_low + alpha_high) / 2.0

        x_new = x + alpha_j * pk
        
        # Evaluate the merit function and the gradient at point i
        f_new = func(x_new)
        g_new = proj_grad_func(x_new)
        proj_g_new = np.dot(g_new.flatten(), pk.flatten())

        # Check if the sufficient decrease condition is violated
        if f_new > fk + c1 * alpha_j * proj_gk or f_new >= f_low:
            if verbose:
                print('Zoom: Sufficient decrease conditions violated')
            alpha_high = alpha_j
            f_high = f_new
            proj_high = proj_g_new
        else:
            # Return alpha, the strong Wolfe conditions are satisfied
            if np.abs(proj_g_new) <= c2 * np.abs(proj_gk):
                if verbose:
                    print('Zoom: Wolfe conditions satisfied')
                return alpha_j

            if proj_g_new * (alpha_high - alpha_low) >= 0.0:
                alpha_high = alpha_low
                f_high = f_low
                proj_high = proj_low

            alpha_low = alpha_j
            f_low = f_new
            proj_low = proj_g_new

        if verbose:
            print(f'Zoom iteration {j}, alpha_j: {alpha_j}')
    
    return alpha_j

def cubic_interp(alpha_low, f_low, proj_low, alpha_high, f_high, proj_high, verbose=False):
    '''
    find a point x within a given interval (x0, x1) that minimizes
    a cubic interpolant. The cubic interpolant is constructed using
    the function values and their derivatives at the endpoints x0 and x1.

    This method does not assume that x0 > x1. If the solution is
    not in the interval, the function returns the mid-point.
    '''
    # Compute d1 
    d1 = proj_low + proj_high - 3 * (f_low - f_high) / (alpha_low - alpha_high)

    # Check that the square root will be real in the expression for d2
    if (d1 ** 2 - proj_low * proj_high) < 0.0:
        if verbose:
            print('Cubic interpolation fail')
        return 0.5 * (alpha_low + alpha_high)
    
    # Compute d2
    d2 = np.sign(alpha_high - alpha_low) * np.sqrt(d1 ** 2 - proj_low * proj_high)

    # Evaluate the new interpolation point
    alpha_j = alpha_high - (alpha_high - alpha_low) * (proj_high + d2 - d1) / (proj_high - proj_low + 2 * d2)

    # If the new point is outside the interval, return the mid point
    if alpha_high > alpha_low and (alpha_j > alpha_high or alpha_j < alpha_low):
        return 0.5 * (alpha_low + alpha_high)
    elif alpha_low > alpha_high and (alpha_j > alpha_low or alpha_j < alpha_high):
        return 0.5 * (alpha_low + alpha_high)

    return alpha_j

# Configuration settings
# mu_values = [2, 3, 4, 5, 6, 7, 9, 10, 11, 14, 15, 16, 20, 21, 22, 27, 28, 29, 35, 36, 37, 44, 45, 46, 54, 55, 56, 65, 66, 67, 77, 78, 79, 90, 91, 92, 104, 105, 106, 119, 120, 121]
mu_values = [2]
s_values = [3]
objectives = [2]
MAX_ITERATIONS = 3000
DISP_RESULTS = False
save_file_path = 'C:\\Users\\7440Test\\Desktop\\The Extention Paper'
runs = 11

for run in range(runs):
    for mu in mu_values:
        for M in objectives:
            for s in s_values:
                # Numerical example
                A = generate_initial_points(mu, M)

                # The result
                optimized_points, gradient_norms, energy_values = steepest_descent(
                    A, func, grad_func, proj_grad_func, 
                    c1=1e-3, c2=0.9, eps=1e-6, 
                    max_iters=MAX_ITERATIONS, verbose=True
                )
                Es = riesz_s_energy(optimized_points, s)

                if DISP_RESULTS:
                    print(optimized_points)
                    print(Es)

                # Save optimized points to CSV
                df_optimized_points = pd.DataFrame(optimized_points, columns=['X', 'Y'])
                df_optimized_points.to_csv(f'{save_file_path}/Results/Data_linear_2D/GD_LINEAR_M{M}_mu{mu}_s{s}_It{MAX_ITERATIONS}_R{run}.pof', index=False)

                # Save gradient norms to CSV
                df_gradient_norms = pd.DataFrame(gradient_norms, columns=['Gradient Norm'])
                df_gradient_norms.to_csv(f'{save_file_path}/Results/Data_linear_2D/GD_LINEAR_LINEAR_M{M}_mu{mu}_s{s}_It{MAX_ITERATIONS}_R{run}.gdn', index=False)

                # Save energy values to CSV
                df_energy_values = pd.DataFrame(energy_values, columns=['Energy Value'])
                df_energy_values.to_csv(f'{save_file_path}/Results/Data_linear_2D/GD_LINEAR_LINEAR_M{M}_mu{mu}_s{s}_It{MAX_ITERATIONS}_R{run}.energy', index=False)

                # Plot for 2D scatter
                fig, ax = plt.subplots()
                # initial_points = np.array(A)
                # ax.scatter(initial_points[:, 0], initial_points[:, 1], c='r', marker='o', label='Initial Points')

                optimized_points = np.array(optimized_points)
                ax.scatter(optimized_points[:, 0], optimized_points[:, 1], c='black', marker='o')

                ax.set_xlabel('f1 ')
                ax.set_ylabel('f2 ')
                # ax.legend()

                if DISP_RESULTS:
                    plt.show()

                # Save the 2D scatter plot
                fig.savefig(f'{save_file_path}/Results/Figures_linear_2D/scatter_GD_LINEAR_optimal_points_M{M}_mu{mu}_s{s}_It{MAX_ITERATIONS}_R{run}.png')
                plt.close(fig)

                # Plot for gradient norms
                plt.figure()
                plt.plot(gradient_norms, label='Gradient Norm')
                plt.xlabel('Iteration')
                plt.ylabel('Gradient Norm')
                plt.title('Gradient Norm over Iterations')
                plt.legend()
                plt.yscale('log')
                plt.xscale('log')

                # Save the gradient norms plot
                plt.savefig(f'{save_file_path}/Results/Figures_linear_2D/gradient_GD_LINEAR_gradient_norm_M{M}_mu{mu}_s{s}_It{MAX_ITERATIONS}_R{run}.png')
                plt.close()

                # Plot for Riesz s-Energy
                plt.figure()
                plt.plot(energy_values, label='Riesz s-Energy')
                plt.xlabel('Iteration')
                plt.ylabel('Riesz s-Energy')
                plt.title('Riesz s-Energy over Iterations')
                plt.legend()
                plt.yscale('log')
                plt.xscale('log')

                # Save the Riesz s-Energy plot
                plt.savefig(f'{save_file_path}/Results/Figures_linear_2D/riesz_energy_GD_LINEAR_energy_values_M{M}_mu{mu}_s{s}_It{MAX_ITERATIONS}_R{run}.png')
                plt.close()
                               